#run.py

from app import app

app.run(port=4000,debug=True)